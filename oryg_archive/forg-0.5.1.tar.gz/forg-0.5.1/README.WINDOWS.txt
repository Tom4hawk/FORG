Windows users:

This program has been successfully run on windows before, but it is
not guaranteed that all flavors will work.  If you have any problems
running this program, please mail me any error message or traceback
that the program gives you in the output window.  This will allow me
to find and fix the problem if I can.

Note that right now, unless you're pretty brave, the forg under
windows is really only meant for python hackers.  It's useable under
UNIX, but due to some differences, the program can be quite flaky
under windows.

Please include information on what version of python you are using,
and which flavor of windows you are running (95/98/NT/2000/Windows ME,
etc) 

Please mail all problems and bugs to <mda@idatar.com>