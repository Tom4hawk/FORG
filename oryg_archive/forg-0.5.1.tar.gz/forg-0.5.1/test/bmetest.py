#!/usr/bin/python
from Tkinter import *
import BookmarkEditor

x = BookmarkEditor.BookmarkEditor('foobar')
x.mainloop()
