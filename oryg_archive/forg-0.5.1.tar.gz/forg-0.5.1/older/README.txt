In this directory you will find ancient code that went with an extremely
early version of this program written for the python GTK+ bindings.  Since
we wanted the program to run on more than just well-supported GTK+ platforms,
we moved to Tkinter (Tk) and we no longer use these modules.

It is extremely unlikely that you will find anything here of any use
unless you're a developer who enjoys a good chuckle out of another
developer's pathetic flailings.
